function loginChange(element) {
    element.innerText="Log Out";
}

function remove(element){
    element.remove();
}

function message(alert){
    alert("Ninja was liked!");
}