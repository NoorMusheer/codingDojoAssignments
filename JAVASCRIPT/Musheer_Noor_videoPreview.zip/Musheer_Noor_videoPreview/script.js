


var x = document.getElementById("randomVideo");
function playVid() { 
    x.play();
}

function pauseVid() { 
    x.pause();
} 

